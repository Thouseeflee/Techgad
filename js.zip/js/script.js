$(document).ready(function(){
  $('#onecarousel').carousel( { interval: 4000 } );
  });
  $(document).ready(function(){
    $('#2carousel').carousel( { interval: 4000 } );
    });
    $(document).ready(function(){
      $('#3carousel').carousel( { interval: 4000 } );
      });
